import 'package:flutter/material.dart';
import 'package:guia/controllers/camera_controller.dart';
import 'package:provider/provider.dart';

class CadastroLugar extends StatefulWidget {
  const new({super.key});

  @override
  State<CadastroLugar> createState() => _CadastroLugarState();
}

class _CadastroLugarState extends State<CadastroLugar> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Consumer<CameraController>(
        builder: (context, cameraControle, _) => Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              children: [
                Container(
                  //primeiro widget
                  decoration: BoxDecoration(
                    border: Border.all(width: 2),
                    borderRadius: BorderRadius.circular(16),
                    image: DecorationImage(
                      image: FileImage(cameraControle.imagemSelecionada!),
                      fit: BoxFit.cover
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
